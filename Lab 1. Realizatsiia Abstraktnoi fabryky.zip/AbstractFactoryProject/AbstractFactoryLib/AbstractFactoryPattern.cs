using System;

namespace AbstractFactoryLib
{
    // Абстрактний клас - зброя
    public abstract class Weapon
    {
        public abstract void Hit();
    }

    // Абстрактний клас - рух
    public abstract class Movement
    {
        public abstract void Move();
    }

    // Клас арбалет
    public class Arbalet : Weapon
    {
        public override void Hit()
        {
            Console.WriteLine("Стріляємо з арбалета");
        }
    }

    // Клас меч
    public class Sword : Weapon
    {
        public override void Hit()
        {
            Console.WriteLine("Б'ємо мечем");
        }
    }

    // Рух польоту
    public class FlyMovement : Movement
    {
        public override void Move()
        {
            Console.WriteLine("Летимо");
        }
    }

    // Рух - біг
    public class RunMovement : Movement
    {
        public override void Move()
        {
            Console.WriteLine("Біжимо");
        }
    }

    // Клас абстрактної фабрики
    public abstract class HeroFactory
    {
        public abstract Movement CreateMovement();
        public abstract Weapon CreateWeapon();
    }

    // Фабрика створення героя (Ельфа), що летить, з арбалетом
    public class ElfFactory : HeroFactory
    {
        public override Movement CreateMovement()
        {
            return new FlyMovement();
        }

        public override Weapon CreateWeapon()
        {
            return new Arbalet();
        }
    }

    // Фабрика створення героя (Воїна), що біжить, з мечем
    public class VoinFactory : HeroFactory
    {
        public override Movement CreateMovement()
        {
            return new RunMovement();
        }

        public override Weapon CreateWeapon()
        {
            return new Sword();
        }
    }

    // Клієнт - сам супергерой
    public class Hero
    {
        private Weapon weapon;
        private Movement movement;

        public Hero(HeroFactory factory)
        {
            weapon = factory.CreateWeapon();
            movement = factory.CreateMovement();
        }

        public void Run()
        {
            movement.Move();
        }

        public void Hit()
        {
            weapon.Hit();
        }
    }
}
