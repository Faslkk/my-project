using System;
using AbstractFactoryLib;

namespace AbstractFactoryApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Створення Ельфа:");
            Hero elf = new Hero(new ElfFactory());
            elf.Hit();
            elf.Run();
            
            Console.WriteLine("\nСтворення Воїна:");
            Hero voin = new Hero(new VoinFactory());
            voin.Hit();
            voin.Run();
            
            Console.ReadLine();
        }
    }
}
